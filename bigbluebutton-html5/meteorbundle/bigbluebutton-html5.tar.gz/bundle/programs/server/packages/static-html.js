(function () {



/* Exports */
Package._define("static-html");

})();
